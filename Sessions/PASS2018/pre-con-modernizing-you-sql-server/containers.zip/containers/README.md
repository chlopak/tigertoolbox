# Application Development and DevOps with SQL Server Containers 

Content here is designed for PASS 2018
<TBD> 
